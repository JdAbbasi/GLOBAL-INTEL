import React from 'react';

export const LeftSidebar: React.FC = () => (
    <aside className="hidden lg:block lg:col-span-3 xl:col-span-3 py-6">
        <div className="sticky top-20 space-y-4">
            {/* Branding moved to main welcome screen. */}
        </div>
    </aside>
);